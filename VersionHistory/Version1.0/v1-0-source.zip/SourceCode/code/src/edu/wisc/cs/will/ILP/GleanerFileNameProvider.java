/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wisc.cs.will.ILP;

/**
 *
 * @author twalker
 */
public interface GleanerFileNameProvider {
    public String getGleanerFileName();
}
