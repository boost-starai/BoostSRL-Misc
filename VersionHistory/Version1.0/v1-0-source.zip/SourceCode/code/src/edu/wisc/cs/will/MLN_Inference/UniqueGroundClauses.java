/**
 * 
 */
package edu.wisc.cs.will.MLN_Inference;

/**
 * @author shavlik
 *
 */
public class UniqueGroundClauses {

	/**
	 * 
	 */
	public UniqueGroundClauses() {
		// TODO Auto-generated constructor stub
	}

}
