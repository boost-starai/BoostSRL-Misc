/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wisc.cs.will.stdAIsearch;

/**
 *
 * @author twalker
 */
public interface StateBasedSearchInputStream {
    StateBasedSearchTask getStateBasedSearchTask();
}
