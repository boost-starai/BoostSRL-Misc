package edu.wisc.cs.will.FOPC.visitors;

public class StopVisitingException extends RuntimeException {
}
