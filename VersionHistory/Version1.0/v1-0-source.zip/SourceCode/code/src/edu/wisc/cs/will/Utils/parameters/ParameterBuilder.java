/*
 * ParameterBuilder.java
 *
 * Created on August 27, 2007, 11:24 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package edu.wisc.cs.will.Utils.parameters;

/**
 *
 * @author twalker
 */
public class ParameterBuilder {
    
    
    
}
