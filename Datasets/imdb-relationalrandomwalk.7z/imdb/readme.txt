1. In order to ground the clauses of the train data, please run the following:

       java -cp edu.wisc.cs.will.GroundRelationalRandomWalks.RunGroundRelationalRandomWalks -grw -mln -i -test "./imdb/5Folds/Fold1/Training/test" -target workedUnder -trees 1 -model "./imdb/5Folds/Fold1/Training/train/models"

2. In order to ground the clauses of the test data, please run the following:

       java -cp edu.wisc.cs.will.GroundRelationalRandomWalks.RunGroundRelationalRandomWalks -grw -mln -i -test "./imdb/5Folds/Fold1/Test/test" -target workedUnder -trees 1 -model "./imdb/5Folds/Fold1/Test/train/models"
